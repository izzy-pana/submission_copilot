import { NextResponse } from "next/server";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const code = searchParams.get("code");
  const error = searchParams.get("error");

  if (error) {
    return NextResponse.json({ ok: false, error }, { status: 400 });
  }

  if (!code) {
    return NextResponse.json({
      ok: true,
      message: "Bullhorn OAuth callback is live. No authorization code was supplied."
    });
  }

  return NextResponse.json({
    ok: true,
    message: "Bullhorn returned an authorization code successfully.",
    receivedCode: true
  });
}
